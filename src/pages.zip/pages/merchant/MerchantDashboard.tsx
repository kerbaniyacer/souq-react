import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Package, ShoppingBag, TrendingUp, Plus, Settings } from 'lucide-react';
import axios from 'axios';
import { useAuthStore } from '@/stores/authStore';
import type { Product, Order } from '@/types';

const DB = 'http://localhost:3001';

export default function MerchantDashboard() {
  const { profile, user } = useAuthStore();
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const sellerId = user?.id ?? profile?.user_id;
    Promise.all([
      axios.get(`${DB}/products?seller_id=${sellerId}`),
      axios.get(`${DB}/orders`),
    ])
      .then(([pRes, oRes]) => {
        setProducts(pRes.data);
        setOrders(oRes.data);
      })
      .finally(() => setLoading(false));
  }, [user?.id, profile?.user_id]);

  const totalRevenue = orders
    .filter((o) => o.status === 'delivered')
    .reduce((s, o) => s + Number(o.total_amount), 0);

  const pendingOrders = orders.filter((o) => o.status === 'pending').length;

  const stats = [
    { label: 'إجمالي المنتجات', value: products.length, icon: <ShoppingBag className="w-6 h-6" />, color: 'bg-blue-100 text-blue-600' },
    { label: 'إجمالي الطلبات', value: orders.length, icon: <Package className="w-6 h-6" />, color: 'bg-purple-100 text-purple-600' },
    { label: 'طلبات معلّقة', value: pendingOrders, icon: <Package className="w-6 h-6" />, color: 'bg-yellow-100 text-yellow-600' },
    { label: 'الإيرادات', value: `${totalRevenue.toLocaleString('ar-DZ')} دج`, icon: <TrendingUp className="w-6 h-6" />, color: 'bg-green-100 text-green-600' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 font-arabic">لوحة التاجر</h1>
          {profile?.store_name && (
            <p className="text-gray-500 font-arabic mt-1">{profile.store_name}</p>
          )}
        </div>
        <div className="flex gap-3">
          <Link
            to="/merchant/products/add"
            className="flex items-center gap-2 px-4 py-2 bg-primary-400 text-white rounded-xl hover:bg-primary-500 transition-colors font-arabic text-sm"
          >
            <Plus className="w-4 h-4" />
            منتج جديد
          </Link>
          <Link
            to="/profile"
            className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors font-arabic text-sm"
          >
            <Settings className="w-4 h-4" />
            الإعدادات
          </Link>
        </div>
      </div>

      {/* Stats */}
      {loading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
          {[...Array(4)].map((_, i) => <div key={i} className="h-28 bg-gray-100 rounded-2xl animate-pulse" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
          {stats.map((stat) => (
            <div key={stat.label} className="bg-white rounded-2xl border border-gray-100 p-5">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${stat.color}`}>
                {stat.icon}
              </div>
              <div className="text-2xl font-bold text-gray-900 font-mono">{stat.value}</div>
              <div className="text-sm text-gray-500 font-arabic mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent products */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-gray-900 font-arabic">آخر المنتجات</h3>
            <Link to="/merchant/products" className="text-sm text-primary-600 hover:underline font-arabic">عرض الكل</Link>
          </div>
          {loading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => <div key={i} className="h-14 bg-gray-100 rounded-xl animate-pulse" />)}
            </div>
          ) : products.length === 0 ? (
            <p className="text-gray-400 font-arabic text-sm text-center py-8">لا توجد منتجات بعد</p>
          ) : (
            <div className="space-y-3">
              {products.slice(0, 5).map((p) => (
                <div key={p.id} className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gray-50 rounded-xl overflow-hidden shrink-0">
                    {p.main_image ? (
                      <img src={p.main_image} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <ShoppingBag className="w-5 h-5 text-gray-300" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 font-arabic line-clamp-1">{p.name}</p>
                    <p className="text-xs text-gray-400 font-arabic">{p.category?.name}</p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-lg font-arabic ${p.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                    {p.is_active ? 'نشط' : 'مخفي'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent orders */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-gray-900 font-arabic">آخر الطلبات</h3>
            <Link to="/merchant/orders" className="text-sm text-primary-600 hover:underline font-arabic">عرض الكل</Link>
          </div>
          {loading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => <div key={i} className="h-14 bg-gray-100 rounded-xl animate-pulse" />)}
            </div>
          ) : orders.length === 0 ? (
            <p className="text-gray-400 font-arabic text-sm text-center py-8">لا توجد طلبات بعد</p>
          ) : (
            <div className="space-y-3">
              {orders.slice(0, 5).map((o) => (
                <Link key={o.id} to={`/merchant/orders/${o.id}`} className="flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 transition-colors">
                  <div>
                    <p className="text-sm font-medium text-gray-800 font-arabic">#{o.order_number}</p>
                    <p className="text-xs text-gray-400 font-arabic">{o.full_name}</p>
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-bold text-primary-600 font-mono">{Number(o.total_amount).toLocaleString('ar-DZ')} دج</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-arabic ${
                      o.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                      o.status === 'delivered' ? 'bg-green-100 text-green-700' :
                      'bg-blue-100 text-blue-700'
                    }`}>
                      {o.status === 'pending' ? 'معلّق' : o.status === 'delivered' ? 'مُسلَّم' : o.status}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
