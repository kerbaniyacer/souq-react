import { useEffect, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { ArrowRight, Plus, Trash2, Save } from 'lucide-react';
import axios from 'axios';
import { useAuthStore } from '@/stores/authStore';
import { useToast } from '@/stores/toastStore';
import type { Category } from '@/types';

const DB = 'http://localhost:3001';

interface VariantForm {
  id?: string;
  name: string;
  sku: string;
  price: string;
  old_price: string;
  discount: string;
  stock: string;
  is_main: boolean;
  is_active: boolean;
}

const emptyVariant = (): VariantForm => ({
  name: '', sku: '', price: '', old_price: '', discount: '0', stock: '0', is_main: false, is_active: true,
});

export default function MerchantProductForm() {
  const { id } = useParams<{ id: string }>();
  const isEdit = Boolean(id);
  const { user } = useAuthStore();
  const toast = useToast();
  const navigate = useNavigate();

  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    name: '', description: '', sku: '', category_id: '',
    is_active: true, is_featured: false,
  });
  const [variants, setVariants] = useState<VariantForm[]>([{ ...emptyVariant(), is_main: true }]);

  // جلب التصنيفات + المنتج عند التعديل
  useEffect(() => {
    axios.get(`${DB}/categories`).then((r) => setCategories(r.data));
    if (isEdit && id) {
      setLoading(true);
      axios.get(`${DB}/products/${id}`).then((r) => {
        const p = r.data;
        setForm({
          name: p.name, description: p.description ?? '',
          sku: p.sku ?? '', category_id: String(p.category_id ?? ''),
          is_active: p.is_active, is_featured: p.is_featured,
        });
        if (p.variants?.length) {
          setVariants(p.variants.map((v: VariantForm & { price: number; old_price: number | null; discount: number; stock: number }) => ({
            id: String(v.id), name: v.name, sku: v.sku,
            price: String(v.price), old_price: v.old_price ? String(v.old_price) : '',
            discount: String(v.discount ?? 0), stock: String(v.stock ?? 0),
            is_main: v.is_main, is_active: v.is_active,
          })));
        }
      }).finally(() => setLoading(false));
    }
  }, [id, isEdit]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setForm((p) => ({ ...p, [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value }));
  };

  const handleVariantChange = (idx: number, field: keyof VariantForm, value: string | boolean) => {
    setVariants((prev) => prev.map((v, i) => {
      if (i !== idx) return v;
      const updated = { ...v, [field]: value };
      // إذا تم تحديد is_main، أزل من الباقين
      if (field === 'is_main' && value === true) return updated;
      return updated;
    }));
    // is_main: أزل من البقية
    if (field === 'is_main' && value === true) {
      setVariants((prev) => prev.map((v, i) => ({ ...v, is_main: i === idx })));
    }
  };

  const addVariant = () => setVariants((p) => [...p, emptyVariant()]);
  const removeVariant = (idx: number) => setVariants((p) => p.filter((_, i) => i !== idx));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) { toast.error('اسم المنتج مطلوب'); return; }
    if (!variants.length) { toast.error('أضف نسخة واحدة على الأقل'); return; }
    if (!variants.some((v) => v.is_main)) { variants[0].is_main = true; }

    setSaving(true);
    try {
      const slug = form.name.trim().toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, '') + '-' + Date.now();
      const cat = categories.find((c) => String(c.id) === form.category_id);

      const productData = {
        ...form,
        slug: isEdit ? undefined : slug,
        seller_id: String(user?.id),
        seller: { id: user?.id, username: user?.username },
        category: cat ? { id: cat.id, name: cat.name, slug: cat.slug } : null,
        rating: 0, reviews_count: 0, sold_count: 0,
        main_image: null, images: [],
        variants: variants.map((v, i) => ({
          id: v.id ?? String(i + 1),
          name: v.name, sku: v.sku,
          price: Number(v.price),
          old_price: v.old_price ? Number(v.old_price) : null,
          discount: Number(v.discount),
          stock: Number(v.stock),
          is_active: v.is_active, is_main: v.is_main,
          attributes: {}, is_in_stock: Number(v.stock) > 0,
        })),
        attributes: [],
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      if (isEdit) {
        await axios.patch(`${DB}/products/${id}`, productData);
        toast.success('تم تحديث المنتج بنجاح');
      } else {
        await axios.post(`${DB}/products`, productData);
        toast.success('تم إضافة المنتج بنجاح 🎉');
      }
      navigate('/merchant/products');
    } catch {
      toast.error('حدث خطأ أثناء الحفظ');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return (
    <div className="max-w-3xl mx-auto px-4 py-10 space-y-4 animate-pulse">
      {[...Array(4)].map((_, i) => <div key={i} className="h-14 bg-gray-100 rounded-xl" />)}
    </div>
  );

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm font-arabic text-gray-400 mb-6">
        <Link to="/merchant/products" className="hover:text-primary-600 transition-colors">منتجاتي</Link>
        <ArrowRight className="w-3 h-3" />
        <span className="text-gray-700">{isEdit ? 'تعديل المنتج' : 'إضافة منتج جديد'}</span>
      </div>

      <h1 className="text-2xl font-bold text-gray-900 font-arabic mb-8">
        {isEdit ? 'تعديل المنتج' : '+ إضافة منتج جديد'}
      </h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* معلومات أساسية */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 space-y-4">
          <h3 className="font-bold text-gray-800 font-arabic border-b border-gray-100 pb-3 mb-4">المعلومات الأساسية</h3>
          <div>
            <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">اسم المنتج *</label>
            <input name="name" value={form.name} onChange={handleChange} required placeholder="مثال: هاتف سامسونج..."
              className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">الوصف</label>
            <textarea name="description" value={form.description} onChange={handleChange} rows={4}
              placeholder="وصف تفصيلي للمنتج..."
              className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic text-sm resize-none" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">القسم</label>
              <select name="category_id" value={form.category_id} onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic text-sm">
                <option value="">اختر القسم</option>
                {categories.map((c) => <option key={c.id} value={String(c.id)}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">رمز المنتج (SKU)</label>
              <input name="sku" value={form.sku} onChange={handleChange} placeholder="PRD-001"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic text-sm" />
            </div>
          </div>
          <div className="flex gap-6">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" name="is_active" checked={form.is_active}
                onChange={(e) => setForm((p) => ({ ...p, is_active: e.target.checked }))}
                className="w-4 h-4 accent-primary-400" />
              <span className="text-sm font-arabic text-gray-700">منتج نشط (ظاهر للزبائن)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" name="is_featured" checked={form.is_featured}
                onChange={(e) => setForm((p) => ({ ...p, is_featured: e.target.checked }))}
                className="w-4 h-4 accent-primary-400" />
              <span className="text-sm font-arabic text-gray-700">منتج مميز</span>
            </label>
          </div>
        </div>

        {/* النسخ */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <div className="flex items-center justify-between border-b border-gray-100 pb-3 mb-5">
            <h3 className="font-bold text-gray-800 font-arabic">النسخ والأسعار</h3>
            <button type="button" onClick={addVariant}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-primary-50 text-primary-600 rounded-lg text-sm font-arabic hover:bg-primary-100 transition-colors">
              <Plus className="w-3.5 h-3.5" /> نسخة جديدة
            </button>
          </div>

          <div className="space-y-4">
            {variants.map((v, idx) => (
              <div key={idx} className={`p-4 rounded-xl border-2 transition-colors ${v.is_main ? 'border-primary-300 bg-primary-50/30' : 'border-gray-100 bg-gray-50/30'}`}>
                <div className="flex items-center justify-between mb-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="is_main" checked={v.is_main}
                      onChange={() => handleVariantChange(idx, 'is_main', true)}
                      className="accent-primary-400" />
                    <span className="text-sm font-arabic text-gray-700">
                      {v.is_main ? '⭐ النسخة الرئيسية' : 'تعيين كرئيسية'}
                    </span>
                  </label>
                  {variants.length > 1 && (
                    <button type="button" onClick={() => removeVariant(idx)}
                      className="p-1 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="text-xs text-gray-500 font-arabic block mb-1">اسم النسخة *</label>
                    <input value={v.name} onChange={(e) => handleVariantChange(idx, 'name', e.target.value)} required
                      placeholder="مثال: أحمر - L"
                      className="w-full px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm font-arabic focus:outline-none focus:ring-2 focus:ring-primary-400/30" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-arabic block mb-1">SKU *</label>
                    <input value={v.sku} onChange={(e) => handleVariantChange(idx, 'sku', e.target.value)} required
                      placeholder="PRD-001-RED"
                      className="w-full px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm font-arabic focus:outline-none focus:ring-2 focus:ring-primary-400/30" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-arabic block mb-1">السعر (دج) *</label>
                    <input type="number" value={v.price} onChange={(e) => handleVariantChange(idx, 'price', e.target.value)} required min="0"
                      className="w-full px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm font-mono focus:outline-none focus:ring-2 focus:ring-primary-400/30" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-arabic block mb-1">السعر القديم (دج)</label>
                    <input type="number" value={v.old_price} onChange={(e) => handleVariantChange(idx, 'old_price', e.target.value)} min="0"
                      className="w-full px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm font-mono focus:outline-none focus:ring-2 focus:ring-primary-400/30" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-arabic block mb-1">المخزون</label>
                    <input type="number" value={v.stock} onChange={(e) => handleVariantChange(idx, 'stock', e.target.value)} min="0"
                      className="w-full px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm font-mono focus:outline-none focus:ring-2 focus:ring-primary-400/30" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* أزرار */}
        <div className="flex gap-3">
          <button type="submit" disabled={saving}
            className="flex-1 py-3.5 bg-primary-400 text-white font-bold rounded-xl hover:bg-primary-500 transition-colors font-arabic flex items-center justify-center gap-2 disabled:opacity-60">
            {saving
              ? <><span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> جاري الحفظ...</>
              : <><Save className="w-5 h-5" /> {isEdit ? 'حفظ التعديلات' : 'إضافة المنتج'}</>
            }
          </button>
          <Link to="/merchant/products"
            className="px-6 py-3.5 bg-white border border-gray-200 text-gray-700 font-arabic rounded-xl hover:bg-gray-50 transition-colors text-center">
            إلغاء
          </Link>
        </div>
      </form>
    </div>
  );
}
