import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, Package } from 'lucide-react';
import axios from 'axios';
import { useToast } from '@/stores/toastStore';
import type { Order, OrderStatus } from '@/types';

const DB = 'http://localhost:3001';

const statusConfig: Record<string, { label: string; color: string; next?: OrderStatus }> = {
  pending:    { label: 'معلّق',         color: 'bg-yellow-100 text-yellow-700',  next: 'confirmed' },
  confirmed:  { label: 'مؤكّد',         color: 'bg-blue-100 text-blue-700',      next: 'processing' },
  processing: { label: 'جاري التجهيز',  color: 'bg-purple-100 text-purple-700',  next: 'shipped' },
  shipped:    { label: 'تم الشحن',       color: 'bg-indigo-100 text-indigo-700',  next: 'delivered' },
  delivered:  { label: 'تم التسليم',     color: 'bg-green-100 text-green-700' },
  cancelled:  { label: 'ملغى',           color: 'bg-red-100 text-red-700' },
  returned:   { label: 'مُرجَع',          color: 'bg-gray-100 text-gray-600' },
};

export default function MerchantOrders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [updating, setUpdating] = useState<string | null>(null);
  const toast = useToast();

  useEffect(() => {
    axios.get(`${DB}/orders`).then((r) => setOrders(r.data)).finally(() => setLoading(false));
  }, []);

  const handleNextStatus = async (order: Order) => {
    const nextStatus = statusConfig[order.status]?.next;
    if (!nextStatus) return;
    setUpdating(String(order.id));
    try {
      await axios.patch(`${DB}/orders/${order.id}`, { status: nextStatus });
      setOrders((prev) => prev.map((o) => String(o.id) === String(order.id) ? { ...o, status: nextStatus } : o));
      toast.success(`تم تحديث الحالة إلى: ${statusConfig[nextStatus].label}`);
    } catch {
      toast.error('تعذّر تحديث الحالة');
    } finally {
      setUpdating(null);
    }
  };

  const handleCancel = async (order: Order) => {
    if (!confirm('هل أنت متأكد من إلغاء هذا الطلب؟')) return;
    setUpdating(String(order.id));
    try {
      await axios.patch(`${DB}/orders/${order.id}`, { status: 'cancelled' });
      setOrders((prev) => prev.map((o) => String(o.id) === String(order.id) ? { ...o, status: 'cancelled' } : o));
      toast.success('تم إلغاء الطلب');
    } catch {
      toast.error('تعذّر إلغاء الطلب');
    } finally {
      setUpdating(null);
    }
  };

  const filtered = statusFilter === 'all' ? orders : orders.filter((o) => o.status === statusFilter);

  const counts = Object.fromEntries(
    Object.keys(statusConfig).map((s) => [s, orders.filter((o) => o.status === s).length])
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 font-arabic">إدارة الطلبات</h1>
          <p className="text-gray-500 font-arabic text-sm mt-1">{orders.length} طلب إجمالي</p>
        </div>
      </div>

      {/* Status filters */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 mb-6">
        <button onClick={() => setStatusFilter('all')}
          className={`shrink-0 px-4 py-2 rounded-xl text-sm font-arabic font-medium transition-colors ${
            statusFilter === 'all' ? 'bg-primary-400 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-gray-300'
          }`}>
          الكل ({orders.length})
        </button>
        {Object.entries(statusConfig).map(([key, cfg]) => counts[key] > 0 && (
          <button key={key} onClick={() => setStatusFilter(key)}
            className={`shrink-0 px-4 py-2 rounded-xl text-sm font-arabic font-medium transition-colors ${
              statusFilter === key ? 'bg-primary-400 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-gray-300'
            }`}>
            {cfg.label} ({counts[key]})
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => <div key={i} className="h-24 bg-gray-100 rounded-2xl animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20">
          <Package className="w-16 h-16 text-gray-200 mx-auto mb-4" />
          <p className="text-gray-400 font-arabic">لا توجد طلبات</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((order) => {
            const cfg = statusConfig[order.status] ?? { label: order.status, color: 'bg-gray-100 text-gray-600' };
            const isUpdating = updating === String(order.id);
            return (
              <div key={order.id} className="bg-white rounded-2xl border border-gray-100 p-5 hover:border-gray-200 transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 flex-wrap">
                      <span className="font-bold text-gray-900 font-mono text-sm">#{order.order_number}</span>
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium font-arabic ${cfg.color}`}>{cfg.label}</span>
                    </div>
                    <p className="text-sm text-gray-600 font-arabic mt-1">{order.full_name} · {order.phone}</p>
                    <p className="text-xs text-gray-400 font-arabic">{order.wilaya}{order.baladia && ` - ${order.baladia}`}</p>
                    {order.items?.length > 0 && (
                      <p className="text-xs text-gray-400 font-arabic mt-1">
                        {order.items.length} منتج{order.items[0]?.product_name && ` · ${order.items[0].product_name}`}
                      </p>
                    )}
                  </div>
                  <div className="text-left shrink-0">
                    <p className="font-bold text-primary-600 font-mono">{Number(order.total_amount).toLocaleString('ar-DZ')} دج</p>
                    <p className="text-xs text-gray-400 mt-0.5">{new Date(order.created_at).toLocaleDateString('ar-DZ')}</p>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 mt-4 pt-4 border-t border-gray-50 flex-wrap">
                  <Link to={`/merchant/orders/${order.id}`}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-50 border border-gray-200 text-gray-600 rounded-lg text-xs font-arabic hover:bg-gray-100 transition-colors">
                    عرض التفاصيل <ChevronLeft className="w-3 h-3" />
                  </Link>

                  {statusConfig[order.status]?.next && (
                    <button onClick={() => handleNextStatus(order)} disabled={isUpdating}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-primary-50 text-primary-600 border border-primary-200 rounded-lg text-xs font-arabic hover:bg-primary-100 transition-colors disabled:opacity-50">
                      {isUpdating
                        ? <span className="w-3 h-3 border border-primary-400 border-t-transparent rounded-full animate-spin" />
                        : '✓'
                      }
                      {statusConfig[statusConfig[order.status].next!]?.label}
                    </button>
                  )}

                  {!['cancelled', 'delivered', 'returned'].includes(order.status) && (
                    <button onClick={() => handleCancel(order)} disabled={isUpdating}
                      className="px-3 py-1.5 bg-red-50 text-red-500 border border-red-200 rounded-lg text-xs font-arabic hover:bg-red-100 transition-colors disabled:opacity-50">
                      إلغاء
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
