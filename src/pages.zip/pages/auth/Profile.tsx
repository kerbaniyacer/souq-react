import { useEffect, useState } from 'react';
import { User, Camera, Save, Lock, Store, ShoppingBag, LayoutDashboard, Package, ClipboardList } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuthStore } from '@/stores/authStore';
import { useToast } from '@/stores/toastStore';
import { WILAYA_CHOICES } from '@/types';

export default function Profile() {
  const { user, profile, fetchProfile, updateProfile } = useAuthStore();
  const toast = useToast();
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'personal' | 'store' | 'password'>('personal');

  const [form, setForm] = useState({
    first_name: '',
    last_name: '',
    phone: '',
    address: '',
    wilaya: '',
    baladia: '',
    bio: '',
    store_name: '',
    store_description: '',
    store_category: '',
  });

  const [passwordForm, setPasswordForm] = useState({
    old_password: '',
    new_password: '',
    confirm_password: '',
  });

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  useEffect(() => {
    if (profile) {
      setForm({
        first_name: user?.first_name ?? '',
        last_name: user?.last_name ?? '',
        phone: profile.phone ?? '',
        address: profile.address ?? '',
        wilaya: profile.wilaya ?? '',
        baladia: profile.baladia ?? '',
        bio: profile.bio ?? '',
        store_name: profile.store_name ?? '',
        store_description: profile.store_description ?? '',
        store_category: profile.store_category ?? '',
      });
    }
  }, [profile, user]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm((p) => ({ ...p, [e.target.name]: e.target.value }));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateProfile(form);
      toast.success('تم حفظ التغييرات بنجاح!');
    } catch {
      toast.error('تعذّر حفظ التغييرات');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10">
      <h1 className="text-2xl font-bold text-gray-900 font-arabic mb-8">الملف الشخصي</h1>

      {/* Avatar + Account Type */}
      <div className="mb-8 p-6 bg-white rounded-2xl border border-gray-100">
        <div className="flex items-center gap-5">
          <div className="relative">
            <div className="w-20 h-20 bg-primary-100 rounded-2xl flex items-center justify-center overflow-hidden">
              {profile?.photo ? (
                <img src={profile.photo} alt="" className="w-full h-full object-cover" />
              ) : (
                <User className="w-10 h-10 text-primary-400" />
              )}
            </div>
            <button className="absolute -bottom-2 -left-2 p-2 bg-primary-400 text-white rounded-lg hover:bg-primary-500 transition-colors shadow-md">
              <Camera className="w-3 h-3" />
            </button>
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-gray-900 font-arabic text-lg">{user?.username}</h3>
            <p className="text-gray-500 text-sm">{user?.email}</p>
            <div className="flex items-center gap-2 mt-2">
              {profile?.is_seller ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-primary-100 text-primary-700 text-xs rounded-full font-arabic font-medium">
                  <Store className="w-3 h-3" />
                  تاجر
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-arabic font-medium">
                  <ShoppingBag className="w-3 h-3" />
                  مشتري
                </span>
              )}
              {user?.is_staff && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-red-100 text-red-700 text-xs rounded-full font-arabic font-medium">
                  مدير
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Merchant quick links */}
        {profile?.is_seller && (
          <div className="mt-5 pt-5 border-t border-gray-100">
            <p className="text-xs text-gray-400 font-arabic mb-3">روابط سريعة للتاجر</p>
            <div className="flex flex-wrap gap-2">
              <Link to="/merchant/dashboard"
                className="flex items-center gap-1.5 px-3 py-2 bg-primary-50 text-primary-600 rounded-xl text-sm font-arabic hover:bg-primary-100 transition-colors border border-primary-200">
                <LayoutDashboard className="w-4 h-4" />
                لوحة التحكم
              </Link>
              <Link to="/merchant/products"
                className="flex items-center gap-1.5 px-3 py-2 bg-primary-50 text-primary-600 rounded-xl text-sm font-arabic hover:bg-primary-100 transition-colors border border-primary-200">
                <Package className="w-4 h-4" />
                منتجاتي
              </Link>
              <Link to="/merchant/orders"
                className="flex items-center gap-1.5 px-3 py-2 bg-primary-50 text-primary-600 rounded-xl text-sm font-arabic hover:bg-primary-100 transition-colors border border-primary-200">
                <ClipboardList className="w-4 h-4" />
                إدارة الطلبات
              </Link>
            </div>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 rounded-xl p-1 mb-6">
        {[
          { key: 'personal', label: 'البيانات الشخصية', icon: <User className="w-4 h-4" /> },
          ...(profile?.is_seller ? [{ key: 'store', label: 'المتجر', icon: <Store className="w-4 h-4" /> }] : []),
          { key: 'password', label: 'كلمة المرور', icon: <Lock className="w-4 h-4" /> },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as typeof activeTab)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-arabic transition-all ${
              activeTab === tab.key ? 'bg-white text-primary-600 shadow-sm font-medium' : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      <form onSubmit={handleSave}>
        {activeTab === 'personal' && (
          <div className="bg-white rounded-2xl border border-gray-100 p-6 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">الاسم الأول</label>
                <input name="first_name" value={form.first_name} onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">اسم العائلة</label>
                <input name="last_name" value={form.last_name} onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">رقم الهاتف</label>
                <input name="phone" value={form.phone} onChange={handleChange} type="tel"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">الولاية</label>
                <select name="wilaya" value={form.wilaya} onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic">
                  <option value="">اختر الولاية</option>
                  {WILAYA_CHOICES.map((w) => <option key={w} value={w}>{w}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">البلدية</label>
                <input name="baladia" value={form.baladia} onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic" />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">العنوان</label>
                <input name="address" value={form.address} onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic" />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">نبذة عنك</label>
                <textarea name="bio" value={form.bio} onChange={handleChange} rows={3}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic resize-none" />
              </div>
            </div>
          </div>
        )}

        {activeTab === 'store' && profile?.is_seller && (
          <div className="bg-white rounded-2xl border border-gray-100 p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">اسم المتجر</label>
              <input name="store_name" value={form.store_name} onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">فئة المتجر</label>
              <input name="store_category" value={form.store_category} onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">وصف المتجر</label>
              <textarea name="store_description" value={form.store_description} onChange={handleChange} rows={4}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic resize-none" />
            </div>
          </div>
        )}

        {activeTab === 'password' && (
          <div className="bg-white rounded-2xl border border-gray-100 p-6 space-y-4">
            {['old_password', 'new_password', 'confirm_password'].map((field) => (
              <div key={field}>
                <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">
                  {field === 'old_password' ? 'كلمة المرور الحالية' : field === 'new_password' ? 'كلمة المرور الجديدة' : 'تأكيد كلمة المرور'}
                </label>
                <input
                  type="password"
                  name={field}
                  value={passwordForm[field as keyof typeof passwordForm]}
                  onChange={(e) => setPasswordForm((p) => ({ ...p, [field]: e.target.value }))}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 font-arabic"
                />
              </div>
            ))}
          </div>
        )}

        {activeTab !== 'password' && (
          <button
            type="submit"
            disabled={loading}
            className="mt-4 w-full py-3.5 bg-primary-400 text-white font-bold rounded-xl hover:bg-primary-500 transition-colors font-arabic flex items-center justify-center gap-2 disabled:opacity-60"
          >
            {loading ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Save className="w-5 h-5" />}
            حفظ التغييرات
          </button>
        )}
      </form>
    </div>
  );
}
