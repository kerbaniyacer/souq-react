import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Eye, EyeOff, Store, User, ShoppingBag } from 'lucide-react';
import { useAuthStore } from '@/stores/authStore';
import { useToast } from '@/stores/toastStore';
import SocialAuthButtons from '@/components/common/SocialAuthButtons';

export default function Register() {
  const [searchParams] = useSearchParams();
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    password2: '',
    is_seller: searchParams.get('type') === 'seller',
  });
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const toast = useToast();
  const navigate = useNavigate();
  const { register } = useAuthStore();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.password !== formData.password2) {
      toast.error('كلمتا المرور غير متطابقتان');
      return;
    }
    if (formData.password.length < 8) {
      toast.error('كلمة المرور يجب أن تكون 8 أحرف على الأقل');
      return;
    }
    setLoading(true);
    try {
      await register({
        username: formData.username,
        email: formData.email,
        password: formData.password,
        is_seller: formData.is_seller,
      });
      toast.success('🎉 تم إنشاء الحساب بنجاح! يمكنك تسجيل الدخول الآن');
      navigate('/login');
    } catch (err: unknown) {
      toast.error((err as Error).message ?? 'حدث خطأ، يرجى المحاولة مرة أخرى');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-page-bg flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-md">

        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2">
            <div className="w-12 h-12 bg-primary-400 rounded-2xl flex items-center justify-center shadow-lg shadow-primary-400/30">
              <Store className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-primary-400 font-arabic">سوق</span>
          </Link>
          <h1 className="text-2xl font-bold text-gray-900 font-arabic mt-6">إنشاء حساب جديد 🎉</h1>
          <p className="text-gray-500 font-arabic mt-2">انضم إلى مجتمع المتسوقين</p>
        </div>

        <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8">

          {/* نوع الحساب */}
          <div className="grid grid-cols-2 gap-3 mb-5">
            <button
              type="button"
              onClick={() => setFormData((p) => ({ ...p, is_seller: false }))}
              className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                !formData.is_seller ? 'border-primary-400 bg-primary-50' : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <User className={`w-6 h-6 ${!formData.is_seller ? 'text-primary-500' : 'text-gray-400'}`} />
              <span className={`text-sm font-arabic font-medium ${!formData.is_seller ? 'text-primary-700' : 'text-gray-600'}`}>
                متسوق
              </span>
            </button>
            <button
              type="button"
              onClick={() => setFormData((p) => ({ ...p, is_seller: true }))}
              className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                formData.is_seller ? 'border-primary-400 bg-primary-50' : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <ShoppingBag className={`w-6 h-6 ${formData.is_seller ? 'text-primary-500' : 'text-gray-400'}`} />
              <span className={`text-sm font-arabic font-medium ${formData.is_seller ? 'text-primary-700' : 'text-gray-600'}`}>
                تاجر
              </span>
            </button>
          </div>

          {/* أزرار التسجيل الاجتماعي */}
          <SocialAuthButtons mode="register" />

          {/* نموذج التسجيل التقليدي */}
          <form onSubmit={handleSubmit} className="space-y-4 mt-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">
                اسم المستخدم
              </label>
              <input
                name="username"
                value={formData.username}
                onChange={handleChange}
                placeholder="اسم المستخدم"
                required
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 focus:border-primary-400 font-arabic transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">
                البريد الإلكتروني
              </label>
              <input
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="example@email.com"
                required
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 focus:border-primary-400 font-arabic transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">
                كلمة المرور
              </label>
              <div className="relative">
                <input
                  name="password"
                  type={showPass ? 'text' : 'password'}
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="8 أحرف على الأقل"
                  required
                  minLength={8}
                  className="w-full px-4 py-3 pl-11 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 focus:border-primary-400 font-arabic transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 font-arabic mb-2">
                تأكيد كلمة المرور
              </label>
              <input
                name="password2"
                type="password"
                value={formData.password2}
                onChange={handleChange}
                placeholder="أعد إدخال كلمة المرور"
                required
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-400/30 focus:border-primary-400 font-arabic transition-all"
              />
            </div>

            {/* شروط الاستخدام */}
            <p className="text-xs text-gray-400 font-arabic text-center leading-relaxed">
              بالتسجيل فأنت توافق على{' '}
              <span className="text-primary-600 cursor-pointer hover:underline">شروط الاستخدام</span>
              {' '}و{' '}
              <span className="text-primary-600 cursor-pointer hover:underline">سياسة الخصوصية</span>
            </p>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 bg-primary-400 text-white font-bold rounded-xl hover:bg-primary-500 transition-colors font-arabic disabled:opacity-60 flex items-center justify-center gap-2 shadow-md shadow-primary-400/20"
            >
              {loading ? (
                <>
                  <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  جاري إنشاء الحساب...
                </>
              ) : 'إنشاء الحساب'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-500 font-arabic">
              لديك حساب بالفعل؟{' '}
              <Link to="/login" className="text-primary-600 font-semibold hover:underline">
                تسجيل الدخول
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
