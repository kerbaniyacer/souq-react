import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ShoppingBag, Shield, Truck, Headphones, ChevronRight, LayoutDashboard, Package } from 'lucide-react';
import { productsApi, categoriesApi } from '@/services/api';
import type { Product, Category } from '@/types';
import ProductCard from '@/components/store/ProductCard';
import { useAuthStore } from '@/stores/authStore';

function HeroSection() {
  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden bg-gradient-to-br from-primary-50 via-white to-sage-light/10">
      {/* Background decor */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 right-10 w-72 h-72 bg-primary-200/30 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-10 w-96 h-96 bg-sage-light/20 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary-100/20 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Text */}
          <div className="text-center lg:text-right animate-fade-in">
            <span className="inline-block px-4 py-2 bg-primary-100 text-primary-700 text-sm rounded-full font-arabic mb-6">
              🛍️ اكتشف أحدث المنتجات
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 font-arabic leading-tight mb-6">
              تسوّق بثقة
              <span className="text-primary-400 block">في كل وقت</span>
            </h1>
            <p className="text-lg text-gray-600 font-arabic leading-relaxed mb-8 max-w-lg mx-auto lg:mx-0">
              اكتشف آلاف المنتجات من أفضل التجار في الجزائر. جودة عالية، أسعار مناسبة، وتوصيل سريع.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-end">
              <Link
                to="/products"
                className="inline-flex items-center gap-2 px-8 py-4 bg-primary-400 text-white rounded-2xl hover:bg-primary-500 transition-all font-arabic text-lg shadow-lg hover:shadow-primary-400/30 hover:shadow-xl"
              >
                <ShoppingBag className="w-5 h-5" />
                تسوّق الآن
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Link
                to="/track-order"
                className="inline-flex items-center gap-2 px-8 py-4 bg-white text-gray-700 rounded-2xl hover:bg-gray-50 transition-all font-arabic text-lg border border-gray-200 shadow-sm"
              >
                تتبع طلبك
              </Link>
            </div>

            {/* Stats */}
            <div className="flex gap-8 mt-12 justify-center lg:justify-end">
              {[
                { value: '+1000', label: 'منتج' },
                { value: '+200', label: 'تاجر' },
                { value: '+5000', label: 'عميل سعيد' },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-2xl font-bold text-primary-600 font-mono">{stat.value}</div>
                  <div className="text-sm text-gray-500 font-arabic">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Image placeholder */}
          <div className="hidden lg:block">
            <div className="relative">
              <div className="w-full aspect-square max-w-lg mx-auto bg-gradient-to-br from-primary-100 to-sage-light/30 rounded-3xl flex items-center justify-center shadow-2xl">
                <ShoppingBag className="w-40 h-40 text-primary-300" />
              </div>
              {/* Floating cards */}
              <div className="absolute -bottom-6 -right-6 bg-white rounded-2xl p-4 shadow-xl border border-gray-100 animate-float">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
                    <Shield className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 font-arabic">دفع آمن 100%</p>
                    <p className="text-sm font-bold text-gray-800 font-arabic">مضمون</p>
                  </div>
                </div>
              </div>
              <div className="absolute -top-6 -left-6 bg-white rounded-2xl p-4 shadow-xl border border-gray-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                    <Truck className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 font-arabic">توصيل سريع</p>
                    <p className="text-sm font-bold text-gray-800 font-arabic">لكل ولايات</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function FeaturesSection() {
  const features = [
    {
      icon: <Truck className="w-6 h-6" />,
      title: 'توصيل سريع',
      desc: 'توصيل إلى جميع ولايات الجزائر خلال 24-48 ساعة',
      color: 'bg-blue-100 text-blue-600',
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: 'دفع آمن',
      desc: 'نظام دفع مؤمّن بالكامل مع عدة خيارات للدفع',
      color: 'bg-green-100 text-green-600',
    },
    {
      icon: <Headphones className="w-6 h-6" />,
      title: 'دعم 24/7',
      desc: 'فريق دعم متاح على مدار الساعة لمساعدتك',
      color: 'bg-purple-100 text-purple-600',
    },
    {
      icon: <ShoppingBag className="w-6 h-6" />,
      title: 'إرجاع مجاني',
      desc: 'ضمان الإرجاع خلال 7 أيام بدون أي شروط',
      color: 'bg-orange-100 text-orange-600',
    },
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f) => (
            <div key={f.title} className="flex items-start gap-4 p-6 rounded-2xl border border-gray-100 hover:border-primary-200 hover:shadow-md transition-all">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${f.color}`}>
                {f.icon}
              </div>
              <div>
                <h3 className="font-bold text-gray-800 font-arabic mb-1">{f.title}</h3>
                <p className="text-sm text-gray-500 font-arabic leading-relaxed">{f.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default function Home() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [newProducts, setNewProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [featuredRes, newRes, catRes] = await Promise.allSettled([
          productsApi.featured(),
          productsApi.list({ ordering: '-created_at', page_size: 8 }),
          categoriesApi.list(),
        ]);

        if (featuredRes.status === 'fulfilled') setFeaturedProducts(featuredRes.value.data.results ?? featuredRes.value.data);
        if (newRes.status === 'fulfilled') setNewProducts(newRes.value.data.results ?? newRes.value.data);
        if (catRes.status === 'fulfilled') setCategories(catRes.value.data.results ?? catRes.value.data);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <div>
      <HeroSection />
      <FeaturesSection />

      {/* Categories */}
      {categories.length > 0 && (
        <section className="py-16 bg-page-bg">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-gray-900 font-arabic">تصفّح الأقسام</h2>
              <Link to="/products" className="flex items-center gap-1 text-primary-600 hover:text-primary-700 text-sm font-arabic">
                عرض الكل <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {categories.slice(0, 6).map((cat) => (
                <Link
                  key={cat.id}
                  to={`/products?category=${cat.slug}`}
                  className="flex flex-col items-center gap-3 p-4 bg-white rounded-2xl border border-gray-100 hover:border-primary-300 hover:shadow-md transition-all group"
                >
                  {cat.logo ? (
                    <img src={cat.logo} alt={cat.name} className="w-12 h-12 object-contain" />
                  ) : (
                    <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center">
                      <ShoppingBag className="w-6 h-6 text-primary-400" />
                    </div>
                  )}
                  <span className="text-xs font-semibold text-gray-700 font-arabic text-center group-hover:text-primary-600 transition-colors">
                    {cat.name}
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Featured Products */}
      {(loading || featuredProducts.length > 0) && (
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-gray-900 font-arabic">منتجات مميزة</h2>
              <Link to="/products?featured=true" className="flex items-center gap-1 text-primary-600 hover:text-primary-700 text-sm font-arabic">
                عرض الكل <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
            {loading ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="bg-gray-100 rounded-2xl aspect-square animate-pulse" />
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
                {featuredProducts.slice(0, 8).map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </div>
        </section>
      )}

      {/* New Products */}
      {(loading || newProducts.length > 0) && (
        <section className="py-16 bg-page-bg">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-gray-900 font-arabic">أحدث المنتجات</h2>
              <Link to="/products?ordering=-created_at" className="flex items-center gap-1 text-primary-600 hover:text-primary-700 text-sm font-arabic">
                عرض الكل <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
            {loading ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="bg-gray-100 rounded-2xl aspect-square animate-pulse" />
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
                {newProducts.slice(0, 8).map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </div>
        </section>
      )}

      {/* CTA - يختلف حسب حالة تسجيل الدخول */}
      <CTASection />
    </div>
  );
}

function CTASection() {
  const { isAuthenticated, profile } = useAuthStore();

  if (isAuthenticated) {
    // تاجر مسجل
    if (profile?.is_seller) {
      return (
        <section className="py-16 bg-gradient-to-br from-primary-50 to-sage-light/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 rounded-2xl mb-6">
              <LayoutDashboard className="w-8 h-8 text-primary-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 font-arabic mb-4">
              مرحباً بك في لوحة التاجر
            </h2>
            <p className="text-gray-600 font-arabic mb-8 max-w-xl mx-auto">
              إدارة منتجاتك، متابعة طلباتك، وتنمية تجارتك بسهولة.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/merchant/products"
                className="inline-flex items-center gap-2 px-8 py-4 bg-primary-400 text-white rounded-2xl hover:bg-primary-500 transition-all font-arabic text-lg shadow-lg hover:shadow-primary-400/30 hover:shadow-xl"
              >
                <Package className="w-5 h-5" />
                منتجاتي
              </Link>
              <Link
                to="/merchant/dashboard"
                className="inline-flex items-center gap-2 px-8 py-4 bg-white text-gray-700 rounded-2xl hover:bg-gray-50 transition-all font-arabic text-lg border border-gray-200 shadow-sm"
              >
                <LayoutDashboard className="w-5 h-5" />
                لوحة التحكم
              </Link>
            </div>
          </div>
        </section>
      );
    }

    // مستخدم عادي مسجل
    return (
      <section className="py-16 bg-gradient-to-br from-primary-50 to-sage-light/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 rounded-2xl mb-6">
            <ShoppingBag className="w-8 h-8 text-primary-600" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 font-arabic mb-4">
            استمتع بتجربة تسوق مميزة
          </h2>
          <p className="text-gray-600 font-arabic mb-8 max-w-xl mx-auto">
            تابع طلباتك، استعرض قائمة رغباتك، واكتشف منتجات جديدة كل يوم.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/orders"
              className="inline-flex items-center gap-2 px-8 py-4 bg-primary-400 text-white rounded-2xl hover:bg-primary-500 transition-all font-arabic text-lg shadow-lg hover:shadow-primary-400/30 hover:shadow-xl"
            >
              <Package className="w-5 h-5" />
              طلباتي
            </Link>
            <Link
              to="/products"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-gray-700 rounded-2xl hover:bg-gray-50 transition-all font-arabic text-lg border border-gray-200 shadow-sm"
            >
              <ShoppingBag className="w-5 h-5" />
              تسوّق الآن
            </Link>
          </div>
        </div>
      </section>
    );
  }

  // غير مسجل - عرض دعوة التسجيل كتاجر
  return (
    <section className="py-16 bg-gradient-to-br from-primary-50 to-sage-light/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl p-10 md:p-14 text-center shadow-sm border border-gray-100">
          <span className="inline-block px-4 py-2 bg-primary-100 text-primary-700 text-sm rounded-full font-arabic mb-6">
            🏪 انضم إلى آلاف التجار
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 font-arabic mb-4">
            هل أنت تاجر؟
          </h2>
          <p className="text-gray-600 font-arabic text-lg mb-8 max-w-2xl mx-auto leading-relaxed">
            ابدأ البيع على سوق الآن واوصل منتجاتك إلى آلاف الزبائن في جميع ولايات الجزائر.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/register?type=seller"
              className="inline-flex items-center gap-2 px-8 py-4 bg-primary-400 text-white rounded-2xl hover:bg-primary-500 transition-all font-arabic text-lg shadow-lg hover:shadow-primary-400/30 hover:shadow-xl"
            >
              <ShoppingBag className="w-5 h-5" />
              ابدأ البيع الآن
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <Link
              to="/login"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white text-gray-700 rounded-2xl hover:bg-gray-50 transition-all font-arabic text-lg border border-gray-200 shadow-sm"
            >
              تسجيل الدخول
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
